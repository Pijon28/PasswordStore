import base64
from hashlib import scrypt
from cryptography.fernet import Fernet
import pyperclip
from getpass_asterisk.getpass_asterisk import getpass_asterisk
import mysql.connector,pickle,random,string

db = mysql.connector.connect(host = 'localhost', user = 'root', passwd = '123')
cur=db.cursor()
cur.execute('use passwordmanager')

def generateKey(masterPassword):
    key = scrypt(masterPassword.encode(), salt=b'bar', n=2, r=1, p=1, dklen=32)
    encryptionKey = base64.b64encode(key)
    return encryptionKey

def encrypt(password,masterPassword):
    key = Fernet(generateKey(masterPassword))
    encryptedPassword = key.encrypt(password.encode())
    return encryptedPassword

def decrypt(password,masterPassword):
    try:
        key = Fernet(generateKey(masterPassword))
        decryptedPassword = key.decrypt(password)
        return decryptedPassword.decode()
    except:
        return "Invalid Key"

def mpcheck(mp): 
    specsym=["$","@","#","%","_","&","*"]
  
    flag=True
  
    if len(mp)<=8:
        print("Length should be atleast 8")
        flag=False
    
    if len(mp)>=50:
        print("Length should be not greater 20")
        flag=False
    
    if not any(char.isdigit() for char in mp):
        print("Password should have at least one numeral")
        flag=False
    
    if not any(char.isupper() for char in mp):
        print("Password should have at least one uppercase letter")
        flag=False
    
    if not any(char.islower() for char in mp):
        print("Password should have atleast one lowercase")
        flag=False
    
    if not any(char in specsym for char in mp):
        print("Password should have atleast one special symbol $@#%")
        flag=False
    
    
    if flag:
        cmp=input("Re-enter your password ")
        if cmp==mp:
            print("Passwords match!")
        else:
            print("Not a match!")
            return
        
        return flag
    
def mpmaker():
    mp = None
    opt=int(input("Do you want a random Master Password?\nif yes, type 1\nif no ,type 2: "))
    if opt==1:
        mp = pwgen()
    else:
        pass
    while True:
        if opt != 1:
            mp=getpass_asterisk("Enter your Master Password (Important: Master passwords cannot be recovered if you forget it!): ")
        
        if(mpcheck(mp)):
            print("Password is valid")
            mphint=input("Enter a hint for you to remember the password: ")
            with open('MP.bin','wb') as f:
                pickle.dump(encrypt(mp,mp),f)
                pickle.dump(mphint,f)
            return mp
        else:
            print("Invalid Password, please try again.") 

        
def pwgen():
    print('hello, this is the password generator!')
    length = int(input('\nEnter the length of password: '))
    lower = string.ascii_lowercase  
    upper = string.ascii_uppercase
    num = string.digits
    symbols = string.punctuation.replace("'","")
    symbols = symbols.replace('"',"")
    combi = lower + upper + num + symbols
    combin = random.sample(combi,length)
    password = "".join(combin)
    return password

def addPass(mast):
    print('-------------------------------------------------------------------------------------------------')
    print("- Adding a Password -")
    website = input("Enter website name: ")
    weblink = input("Enter website link: ")
    username = input("Enter username: ")
    while True:
        passChoice = int(input("1. Password Generator\n2. Custom Password\nChoice: "))
        if passChoice == 1:
            pw = pwgen()
            print(pw)
            sel = input('Use the above password? (Y/N): ')
            if sel in 'Yy':
                password = pw
                break
        elif passChoice == 2:
            password = getpass_asterisk("Enter your password: ")
            if mpcheck(password):
                break
    cur.execute(f"insert into Passwords (website, weblink, username, passwd) values ('{website}','{weblink}','{encrypt(username,mast).decode()}','{encrypt(password,mast).decode()}')")
    print("Password added.")

def changePass(mast):
    cur.execute('select count(*) from Passwords')
    for i in cur:
        if i[0] == 0:
            print("Database has no passwords. Add a password first.")
            return
    
    print('-------------------------------------------------------------------------------------------------')
    print("- Changing a Password -")
    website = input("Which website to change password for: ")
    cur.execute('select website from Passwords')
    websites = []
    for site in cur:
        websites.append(site[0])
    if website in websites:
        while True:
            passChoice = int(input("1. Password Generator\n2. Custom Password\nChoice: "))
            if passChoice == 1:
                pw = pwgen()
                print(pw)
                sel = input('Use the above password? (Y/N): ')
                if sel in 'Yy':
                    password = pw
                    break
            elif passChoice == 2:
                password = getpass_asterisk("Enter the new password: ")
                if mpcheck(password):
                    break
        cur.execute(f"UPDATE Passwords SET passwd = '{encrypt(password,mast).decode()}' WHERE website = '{website}'")
        print("Password changed.")
    else:
        print("Website not in database.")

def viewPass(mast):
    cur.execute('select count(*) from Passwords')
    for i in cur:
        if i[0] == 0:
            print("Database has no passwords. Add a password first.")
            return
    
    print('-------------------------------------------------------------------------------------------------')
    cur.execute('select * from Passwords')
    passwords = []
    for i in cur:
        passwords.append(i)
    print("- All Passwords -".center(93))
    print(f"{'Sr No.'.center(6)} | {'Website'.center(15)} | {'Website Link'.center(20)} | {'Username'.center(20)} | {'Password'.center(20)}")
    for entry in passwords:
        print(f"{str(entry[0]).center(6)} | {entry[1].center(15)} | {entry[2].center(20)} | {decrypt(entry[3],mast).center(20)} | {decrypt(entry[4],mast).center(20)}")

def retrievePass(mast):
    cur.execute('select count(*) from Passwords')
    for i in cur:
        if i[0] == 0:
            print("Database has no passwords. Add a password first.")
            return
    
    print('-------------------------------------------------------------------------------------------------')
    print("- Retrieving a Password -")
    website = input("Which website to retrieve password for: ")
    cur.execute('select website from Passwords')
    websites = []
    for site in cur:
        websites.append(site[0])
    if website in websites:
        cur.execute(f'select passwd from Passwords where website = "{website}"')
        for i in cur:
            encryptedPassword = i[0]
        password = decrypt(encryptedPassword,mast)
        if password == "Invalid Token":
            print("Password encrypted under different master password. Cannot Copy.")
        else:
            pyperclip.copy(password)
        print(f"Password for {website} copied to clipboard.")
    else:
        print("Website not in database.")

def delPass():
    cur.execute('select count(*) from Passwords')
    for i in cur:
        if i[0] == 0:
            print("Database has no passwords. Add a password first.")
            return
    
    print('-------------------------------------------------------------------------------------------------')
    print("- Deleting a Password -")
    website = input("Which website to delete password for: ")
    cur.execute('select website from Passwords')
    websites = []
    for site in cur:
        websites.append(site[0])
    if website in websites:
        cur.execute(f'delete from Passwords where website = "{website}"')
        print("Password deleted.")
    else:
        print("Website not in database.")
        
while True:
    print('-------------------------------------------------------------------------------------------------')
    print('Welcome to Password Manager')
    sel1 = int(input("1. Access your passwords\n2. Create/Reset Password Database\n3. Change Existing Master Password\n4. Close Password Manager\nChoice: "))
    if sel1 == 1:
        access = False
        while True:
            mast = getpass_asterisk("Enter your master password (Type '<' to exit, 'hint' for master password hint.): ")
            try:
                with open('MP.bin','rb') as f:
                    offset = pickle.load(f)
                    if mast == 'hint':
                        offset = pickle.load(f)
                        print(f"Hint: {pickle.load(f)}")
                        f.seek(0)
                    elif mast == decrypt(pickle.load(f),mast):
                        access = True
                        break
                    elif mast == '<':
                        break
                    else:
                        print("Incorrect password.")
            except EOFError:
                print("No master password has been created; Please create the database first.")
                break
        if access == True:
            while True:
                print('-------------------------------------------------------------------------------------------------')
                print("- Managing Passwords -")
                sel = input("1. Add Password\n2. Change a Password\n3. View all Passwords\n4. Retrieve a Password\n5. Delete a Password\n6. Exit Session\nChoice: ")
                if sel == '1':
                    addPass(mast)
                    db.commit()
                elif sel == '2':
                    changePass(mast)
                    db.commit()
                elif sel == '3':
                    viewPass(mast)
                elif sel == '4':
                    retrievePass(mast)
                elif sel == '5':
                    delPass()
                    db.commit()
                elif sel == '6':
                    break

    elif sel1 == 2:
        mpmaker()
        cur.execute('delete from Passwords')
        db.commit()
    elif sel1 == 3:
        print("Changing master password will involve re-encrypting all passwords to fit the new master password.")
        access = False
        while True:
            mast = getpass_asterisk("Enter your master password (Type '<' to exit, 'hint' for master password hint.): ")
            try:
                with open('MP.bin','rb') as f:
                    if mast == 'hint':
                        offset = pickle.load(f)
                        print(f"Hint: {pickle.load(f)}")
                        f.seek(0)
                    elif mast == decrypt(pickle.load(f),mast):
                        access = True
                        break
                    elif mast == '<':
                        break
                    else:
                        print("Incorrect password.")
            except EOFError:
                print("No master password has been created; Please create the database first.")
                break
        if access == True:
            print("- Enter new Master Password -")
            newMast = mpmaker()
            cur.execute('select website,username,passwd from Passwords;')
            webPass = {}
            for password in cur:
                webPass[password[0]] = [password[1],password[2]]
            for website in webPass:
                webPass[website] = [decrypt(webPass[website][0],mast),decrypt(webPass[website][1],mast)]
                cur.execute(f'update Passwords set username = "{encrypt(webPass[website][0],newMast).decode()}", passwd = "{encrypt(webPass[website][1],newMast).decode()}" where website = "{website}"')
                db.commit()
            print("Passwords re-encrypted.")
    elif sel1 == 4:
        print("Closed password manager.")
        break