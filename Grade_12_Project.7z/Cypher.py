from tkinter import *
from tkinter import messagebox
from tkinter.ttk import *
import pickle
import base64
from hashlib import scrypt
from cryptography.fernet import Fernet
import mysql.connector
import pyperclip
import string
import random

mydb = mysql.connector.connect(host = 'localhost', user = 'root', passwd = '123')
cur = mydb.cursor()
cur.execute('create database if not exists passwordmanager')
cur.execute('use passwordmanager')
cur.execute("""create table if not exists Passwords(
sno int primary key not null default 0,
website varchar(999) not null default '',
weblink varchar(999) not null default '',
username varchar(999) not null default '',
passwd varchar(999) not null default ''
);""")
mydb.commit()

root = Tk()
root.minsize(1000,800)
root.title("Cypher")
x = int(root.winfo_screenwidth()/2) - 500
y = int(root.winfo_screenheight()/2) - 400
root.geometry(f'1000x800+{x}+{y}')

rootFrame = Frame(root,height=800,width=1000)
rootFrame.grid()

s = Style()
s.configure('Title.TLabel',foreground='gray', font=('Patua One',30),anchor='bottom', padding=20)
s.configure('Subtitle.TLabel',foreground='gray', font=('Patua One',15),anchor='bottom', padding=20)
s.configure('Text.TLabel', font=('Patua One',15),padding=5,wraplength=500)
s.configure('Entry.TEntry', font=('Patua One',10),padding=5)
s.configure('Button.TButton',font=('Patua One',15),padding=5)

def generateKey(masterPassword):
    key = scrypt(masterPassword.encode(), salt=b'bar', n=2, r=1, p=1, dklen=32)
    encryptionKey = base64.b64encode(key)
    return encryptionKey

def encrypt(password,masterPassword):
    key = Fernet(generateKey(masterPassword))
    encryptedPassword = key.encrypt(password.encode())
    return encryptedPassword

def decrypt(password,masterPassword):
    try:
        key = Fernet(generateKey(masterPassword))
        decryptedPassword = key.decrypt(password)
        return decryptedPassword.decode()
    except:
        return "Invalid Key"

class Page(Frame):
    def __init__(self, *args, **kwargs):
        Frame.__init__(self, *args, **kwargs)
        
    def hide(self):
        self.place_forget()

class Menu(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Cypher -',style='Title.TLabel')
        title.grid(row=0,column=0)

        regButton = Button(self, text='Register',command=lambda: regpage.show(), style='Button.TButton')
        regButton.grid(row=1,column=0)
        logButton = Button(self, text='Login',command=lambda: logpage.show(), style='Button.TButton')
        logButton.grid(row=2,column=0)
        changeButton = Button(self, text='Modify Acc.',command=lambda: mploginpage.show(), style='Button.TButton')
        changeButton.grid(row=3,column=0)    
    def show(self):
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        regpage.hide()
class RegPage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Registration -',style='Title.TLabel')
        title.grid(row=0,column=0)

        self.user=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.mp=Entry(self,style='Entry.TEntry',font=('Patua One',10),show='*')
        self.cmp=Entry(self,style='Entry.TEntry',font=('Patua One',10),show='*')
        self.hint=Entry(self,style='Entry.TEntry',font=('Patua One',10))

        self.user.grid(row=2,column=0)
        self.mp.grid(row=4,column=0)
        self.cmp.grid(row=6,column=0)
        self.hint.grid(row=8,column=0)

        utext=Label(self,text="Enter your username: ",style='Text.TLabel').grid(row=1,column=0)
        self.user.insert(0,"")
        mptext=Label(self,text="Enter your master password: ",style='Text.TLabel').grid(row=3,column=0)
        self.mp.insert(0,"")
        cmptext=Label(self,text="Confirm master password: ",style='Text.TLabel').grid(row=5,column=0)
        self.cmp.insert(0,"")
        hinttext=Label(self,text="Master Password Hint: ",style='Text.TLabel').grid(row=7,column=0)
        self.hint.insert(0,"")

        space = Label(self,text="").grid(row=9,column=0)
        submitButton=Button(self,text="Submit",style='Button.TButton',command=lambda: self.submitter()).grid(row=10,column=0)
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back())
        backButton.grid(row=11,column=0)
    def show(self):
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        self.enterBind = root.bind('<Return>',func= self.submitter)
        menu.hide()
    def back(self):
        self.hide()
        menu.show()
        self.clearFields()
        root.unbind('<Return>', self.enterBind)
    def submitter(self, *args):
        user=self.user.get()
        mp=self.mp.get()
        cmp=self.cmp.get()
        hint=self.hint.get()

        if not self.mpcheck(mp,cmp):
            messagebox.showinfo(title="Password Checker",message=f"Password Requirements not met:\n{self.error}",icon='warning')
        
        if self.mpcheck(mp,cmp):
            messagebox.showinfo(title="Account Creation Successful",message=f"Account Creation Successful.")
            with open('MP.bin','wb') as f:
                pickle.dump(user,f)
                pickle.dump(encrypt(mp,mp),f)
                pickle.dump(hint,f)
            cur.execute('delete from passwords')
            self.clearFields()
            mydb.commit()
            self.hide()
            menu.show()
    def mpcheck(self,mp,cmp): 
        specsym=["$","@","#","%","_","&","*"]
        flag=True
        self.error = ""

        if len(mp)<=8:
            self.error += "Length should be atleast 8.\n"
            flag=False
        if len(mp)>=50:
            self.error += "Length should be not greater 20.\n"
            flag=False
        if not any(char.isdigit() for char in mp):
            self.error += "Password should have at least one numeral.\n"
            flag=False     
        if not any(char.isupper() for char in mp):
            self.error += "Password should have at least one uppercase letter.\n"
            flag=False
        if not any(char.islower() for char in mp):
            self.error += "Password should have atleast one lowercase.\n"
            flag=False
        if not any(char in specsym for char in mp):
            self.error += "Password should have atleast one special symbol: $@#%\n"
            flag=False
        if mp != cmp:
            self.error += "Passwords do not match.\n"
            flag=False
            
        return flag   
    def clearFields(self):
        self.user.delete(0,'end')
        self.mp.delete(0,'end')
        self.cmp.delete(0,'end')
        self.hint.delete(0,'end')
class LoginPage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Log in -',style='Title.TLabel')
        title.grid(row=0,column=0)

        self.user=Entry(self, font=('Patua One',10))
        self.mp=Entry(self, font=('Patua One',10),show='*')

        self.user.grid(row=2,column=0)
        self.mp.grid(row=4,column=0)

        utext=Label(self,text="Enter your user name: ",style='Text.TLabel').grid(row=1,column=0)
        self.user.insert(0,"")
        mptext=Label(self,text="Enter your master password: ",style='Text.TLabel').grid(row=3,column=0)
        self.mp.insert(0,"")
        
        hintButton=Button(self,text="MP Hint",style='Button.TButton',command=lambda: self.showHint()).grid(row=5,column=0)

        space = Label(self,text="").grid(row=6,column=0)
        enterButton=Button(self,text="Enter",style='Button.TButton',command=lambda: self.loginCheck()).grid(row=7,column=0)
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back()).grid(row=8,column=0)
    def show(self):
        try:
            with open('MP.bin','rb') as f:
                test = pickle.load(f)
        except FileNotFoundError:
            messagebox.showinfo(title="No Account",message=f"No account created on this device.",icon='warning')
            return
        except EOFError:
            messagebox.showinfo(title="No Account",message=f"No account created on this device.",icon='warning')
            return
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        self.enterBind =root.bind('<Return>',self.loginCheck)
        menu.place_forget()
    def back(self):
        root.unbind('<Return>',self.enterBind)
        self.hide()
        self.clearFields()
        menu.show()
    def loginCheck(self,*args):
        user = self.user.get()
        mp = self.mp.get()
        try:
            with open('MP.bin','rb') as f:
                if user != pickle.load(f):
                    messagebox.showinfo(title="Incorrect Username",message=f"Username not found on device.",icon='warning')
                elif mp != decrypt(pickle.load(f),mp):
                    messagebox.showinfo(title="Incorrect Password",message=f"Incorrect Password.",icon='warning')
                else:
                    managerpage.mp = mp
                    root.unbind('<Return>',self.enterBind)
                    managerpage.refreshUser()
                    managerpage.show()
                    self.clearFields()
        except EOFError:
            pass
    def showHint(self):
        with open('MP.bin','rb') as f:
            offset = (pickle.load(f),pickle.load(f))
            messagebox.showinfo(title='Master Password Hint',message=f'Hint: {pickle.load(f)}')
    def clearFields(self):
        self.user.delete(0,'end')
        self.mp.delete(0,'end')
class ManagerPage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='n',relx=0.5,rely=0.1)

        title = Label(self, text='- Passwords -',style='Title.TLabel',padding=0)
        title.grid(row=0,column=0)
        
        self.subtitle = Label(self, text=f'',style='Subtitle.TLabel')
        self.subtitle.grid(row=1,column=0)
        
        pdContainer = Frame(self)
        pdContainer.grid(row=2,column=0)

        pdCanvas = Canvas(pdContainer,height=550,width=850)
        scrollbar = Scrollbar(pdContainer, orient='vertical',command=pdCanvas.yview)
        self.pdFrame = Frame(pdCanvas,height=550,width=850)

        self.pdFrame.bind('<Configure>', lambda e: pdCanvas.configure(scrollregion=pdCanvas.bbox('all')))
        self.pdFrame.grid_columnconfigure(0,minsize=5)
        self.pdFrame.grid_columnconfigure(1,minsize=170)
        self.pdFrame.grid_columnconfigure(2,minsize=170)
        self.pdFrame.grid_columnconfigure(3,minsize=325)
        self.pdFrame.grid_columnconfigure(4,minsize=85)
        pdCanvas.create_window((0,0), window=self.pdFrame, anchor='nw')
        pdCanvas.configure(yscrollcommand=scrollbar.set)

        self.mp = ''
                
        pdCanvas.pack(side='left',fill='both',expand=True)
        scrollbar.pack(side='right', fill='y')
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back())
        backButton.grid(row=3,column=0)
    def show(self):
        self.place(anchor='n',relx=0.5,rely=0.1)
        self.lift()
        self.refreshPW()
        logpage.hide()
    def back(self):
        self.hide()
        menu.show()
    def refreshUser(self):
        with open('MP.bin','rb') as f:
            self.subtitle.config(text=f'Welcome to Cypher, {pickle.load(f)}')
    def refreshPW(self):
        cur.execute('select * from passwords')
        self.passwords = cur.fetchall()
        self.pwcount = len(self.passwords)
        ABIndex = 0
        for widget in self.pdFrame.winfo_children():
            widget.destroy()
        Hsno = Label(self.pdFrame, text='No.', style='Text.TLabel', wraplength=65)
        Hsno.grid(row=0,column=0)
        Hsite = Label(self.pdFrame, text='Website', style='Text.TLabel', wraplength=130)
        Hsite.grid(row=0,column=1)
        Huser = Label(self.pdFrame, text='Username', style='Text.TLabel', wraplength=130)
        Huser.grid(row=0,column=2)
        Hpw = Label(self.pdFrame, text='Password', style='Text.TLabel', wraplength=260)
        Hpw.grid(row=0,column=3)

        for i in range(len(self.passwords)):
            sno = Label(self.pdFrame, text=self.passwords[i][0], style='Text.TLabel', wraplength=65)
            sno.grid(row=i+1,column=0)
            site = Label(self.pdFrame, text=self.passwords[i][1], style='Text.TLabel', wraplength=130)
            site.grid(row=i+1,column=1)
            user = Label(self.pdFrame, text=decrypt(self.passwords[i][3],self.mp), style='Text.TLabel', wraplength=130)
            user.grid(row=i+1,column=2)
            pw = Label(self.pdFrame, text='**********', style='Text.TLabel', wraplength=260)
            pw.grid(row=i+1,column=3)
            oper = Button(self.pdFrame, text='...', style='Button.TButton', padding=0, command= lambda i=i: self.showOper(i))
            oper.grid(row=i+1,column=4)
            ABIndex += 1
        addButton = Button(self.pdFrame, text=' + ', style='Button.TButton',command= lambda: self.addPass())
        addButton.grid(row=ABIndex+1,column=0,columnspan=5,sticky='we')
    def addPass(self):
        addpasspage.show()
    def showOper(self, pwi):
        self.operPage = PWOper(rootFrame)
        self.operPage.pwi = pwi
        self.operPage.mp = self.mp
        self.operPage.showPass()
        self.operPage.show()
class AddPassPage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Add Password -',style='Title.TLabel')
        title.grid(row=0,column=0)

        self.site=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.link=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.user=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.pw=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        
        self.site.grid(row=2,column=0)
        self.link.grid(row=4,column=0)
        self.user.grid(row=6,column=0)
        self.pw.grid(row=8,column=0)

        siteText = Label(self,text='Site Name:',style='Text.TLabel').grid(row=1,column=0)
        linkText = Label(self,text='Site Link:',style='Text.TLabel').grid(row=3,column=0)
        userText = Label(self,text='Username:',style='Text.TLabel').grid(row=5,column=0)
        pwText = Label(self,text='Password:',style='Text.TLabel').grid(row=7,column=0)

        pwgen = Button(self,text='Randomize',style='Button.TButton',command= lambda: self.pwgen())
        pwgen.grid(row=9,column=0)

        space = Label(self,text="").grid(row=10,column=0)
        addButton = Button(self, text='Add',command= self.addPass, style='Button.TButton')
        addButton.grid(row=11,column=0)
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back())
        backButton.grid(row=12,column=0)
    def show(self):
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        self.enterBind = root.bind('<Return>', self.addPass)
        managerpage.hide()
    def back(self):
        self.hide()
        managerpage.show()
        self.clearFields()
        root.unbind('<Return>', self.enterBind)
    def addPass(self, *args):
        site = self.site.get()
        link = self.link.get()
        user = self.user.get()
        pw = self.pw.get()
        if not (site and link and user and pw):
            messagebox.showinfo(title="Empty Fields",message=f"Please fill in all fields.",icon='warning')
            return
        if not self.mpcheck(pw):
            messagebox.showinfo(title="Password Checker",message=f"Password Requirements not met:\n{self.error}",icon='warning')
            return
        cur.execute('insert into passwords values (%s,%s,%s,%s,%s)', (managerpage.pwcount+1,site,link,encrypt(user,managerpage.mp).decode(),encrypt(pw,managerpage.mp).decode()))
        mydb.commit()
        self.back()
    def pwgen(self):
        lower = string.ascii_lowercase  
        upper = string.ascii_uppercase
        num = string.digits
        symbols = ["$","@","#","%","_","&","*"]
        combi = random.sample(lower,4) + random.sample(upper,4) + random.sample(num,4) + random.sample(symbols,4)
        random.shuffle(combi)
        password = ''.join(combi)
        self.pw.delete(0,'end')
        self.pw.insert(0,password)
    def clearFields(self):
        self.site.delete(0,'end')
        self.link.delete(0,'end')
        self.user.delete(0,'end')
        self.pw.delete(0,'end')
    def mpcheck(self,mp): 
        specsym=["$","@","#","%","_","&","*"]
        flag=True
        self.error = ""

        if len(mp)<=8:
            self.error += "Length should be atleast 8.\n"
            flag=False
        if len(mp)>=50:
            self.error += "Length should be not greater 20.\n"
            flag=False
        if not any(char.isdigit() for char in mp):
            self.error += "Password should have at least one numeral.\n"
            flag=False     
        if not any(char.isupper() for char in mp):
            self.error += "Password should have at least one uppercase letter.\n"
            flag=False
        if not any(char.islower() for char in mp):
            self.error += "Password should have atleast one lowercase.\n"
            flag=False
        if not any(char in specsym for char in mp):
            self.error += "Password should have atleast one special symbol: $@#%\n"
            flag=False
            
        return flag
class PWOper(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Password Operations -',style='Title.TLabel')
        title.grid(row=0,column=0,columnspan=4)

        Hsno = Label(self, text='No.', style='Text.TLabel', wraplength=65)
        Hsno.grid(row=1,column=0)
        Hsite = Label(self, text='Website', style='Text.TLabel', wraplength=130)
        Hsite.grid(row=1,column=1)
        Huser = Label(self, text='Username', style='Text.TLabel', wraplength=130)
        Huser.grid(row=1,column=2)
        Hpw = Label(self, text='Password', style='Text.TLabel', wraplength=260)
        Hpw.grid(row=1,column=3)
        
        viewButton = Button(self, text='View',style='Button.TButton')
        viewButton.grid(row=3,column=0)
        viewButton.bind('<ButtonPress-1>',self.viewPassOn)
        viewButton.bind('<ButtonRelease-1>',self.viewPassOff)
        editButton = Button(self, text='Edit',style='Button.TButton',command=lambda: self.editPass())
        editButton.grid(row=3,column=1)
        copyButton = Button(self, text='Copy',style='Button.TButton',command=lambda: self.copyPass())
        copyButton.grid(row=3,column=2)
        deleteButton = Button(self, text='Delete',style='Button.TButton',command=lambda: self.deletePass())
        deleteButton.grid(row=3,column=3)
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back())
        backButton.grid(row=4,column=0,columnspan=4)
    def show(self):
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        managerpage.place_forget()
    def back(self):
        self.hide()
        managerpage.show()
    def showPass(self):
        self.sno = Label(self, text=managerpage.passwords[self.pwi][0], style='Text.TLabel', wraplength=65)
        self.sno.grid(row=2,column=0)
        self.site = Label(self, text=managerpage.passwords[self.pwi][1], style='Text.TLabel', wraplength=130)
        self.site.grid(row=2,column=1)
        self.user = Label(self, text=decrypt(managerpage.passwords[self.pwi][3],self.mp), style='Text.TLabel', wraplength=130)
        self.user.grid(row=2,column=2)
        self.pw = Label(self, text='**********', style='Text.TLabel', wraplength=260)
        self.pw.grid(row=2,column=3)
    def viewPassOn(self,*args):
        self.pw.config(text=decrypt(managerpage.passwords[self.pwi][4],self.mp))
    def viewPassOff(self,*args):
        self.pw.config(text='**********')
    def editPass(self):
        editpasspage = EditPassPage(rootFrame)
        editpasspage.pwi = self.pwi
        editpasspage.mp = self.mp
        editpasspage.getPass()
        editpasspage.show()
    def copyPass(self):
        pw = self.pw.cget('text')
        pyperclip.copy(decrypt(managerpage.passwords[self.pwi][4],self.mp))
        messagebox.showinfo(title="Password copied",message=f"Password copied to clipboard.")
    def deletePass(self):
        confirm = messagebox.askyesno(title="Deletion Confirmation",message=f"Are you sure you want to delete the password for {self.site.cget('text')}?")
        if confirm == True:
            cur.execute('delete from passwords where sno = %s', (self.sno.cget('text'),))
            messagebox.showinfo(title="Password deleted",message=f"Password successfully deleted")
            self.updatePassSno()
            self.back()
        elif confirm == False:
            return
        mydb.commit()
    def updatePassSno(self):
        cur.execute('select * from passwords order by sno')
        passwords = cur.fetchall()
        snolist = [i[0] for i in passwords]
        for i in range(len(snolist)):
            cur.execute('update passwords set sno = %s where sno = %s', (i+1,snolist[i]))
        mydb.commit()
class EditPassPage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Editing -',style='Title.TLabel')
        title.grid(row=0,column=0)

        self.site=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.link=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.user=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.pw=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        
        self.site.grid(row=2,column=0)
        self.link.grid(row=4,column=0)
        self.user.grid(row=6,column=0)
        self.pw.grid(row=8,column=0)

        siteText = Label(self,text='Site Name:',style='Text.TLabel').grid(row=1,column=0)
        linkText = Label(self,text='Site Link:',style='Text.TLabel').grid(row=3,column=0)
        userText = Label(self,text='Username:',style='Text.TLabel').grid(row=5,column=0)
        pwText = Label(self,text='Password:',style='Text.TLabel').grid(row=7,column=0)

        pwgen = Button(self,text='Randomize',style='Button.TButton',command= lambda: self.pwgen())
        pwgen.grid(row=9,column=0)

        space = Label(self,text="").grid(row=10,column=0)
        editButton = Button(self, text='Edit',command= self.editPass, style='Button.TButton')
        editButton.grid(row=11,column=0)
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back())
        backButton.grid(row=12,column=0)
    def show(self):
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        self.enterBind = root.bind('<Return>', self.editPass)
        managerpage.operPage.hide()
    def back(self):
        self.hide()
        managerpage.operPage.show()
        root.unbind('<Return>', self.enterBind)
    def getPass(self):
        self.site.delete(0,'end')
        self.link.delete(0,'end')
        self.user.delete(0,'end')
        self.pw.delete(0,'end')
        self.site.insert(0,managerpage.passwords[self.pwi][1])
        self.link.insert(0,managerpage.passwords[self.pwi][2])
        self.user.insert(0,decrypt(managerpage.passwords[self.pwi][3],self.mp))
        self.pw.insert(0,decrypt(managerpage.passwords[self.pwi][4],self.mp))
    def editPass(self, *args):
        site = self.site.get()
        link = self.link.get()
        user = self.user.get()
        pw = self.pw.get()
        if not (site and link and user and pw):
            messagebox.showinfo(title="Empty Fields",message=f"Please fill in all fields.",icon='warning')
            return
        if not self.mpcheck(pw):
            messagebox.showinfo(title="Password Checker",message=f"Password Requirements not met:\n{self.error}",icon='warning')
            return
        cur.execute('update passwords set website = %s, weblink = %s, username = %s, passwd = %s where sno = %s', (site,link,encrypt(user,managerpage.mp).decode(),encrypt(pw,managerpage.mp).decode(),self.pwi+1))
        mydb.commit()
        managerpage.refreshPW()
        managerpage.operPage.showPass()
        self.back()
    def pwgen(self):
        lower = string.ascii_lowercase  
        upper = string.ascii_uppercase
        num = string.digits
        symbols = ["$","@","#","%","_","&","*"]
        combi = random.sample(lower,4) + random.sample(upper,4) + random.sample(num,4) + random.sample(symbols,4)
        random.shuffle(combi)
        password = ''.join(combi)
        self.pw.delete(0,'end')
        self.pw.insert(0,password)
    def mpcheck(self,mp): 
        specsym=["$","@","#","%","_","&","*"]
        flag=True
        self.error = ""

        if len(mp)<=8:
            self.error += "Length should be atleast 8.\n"
            flag=False
        if len(mp)>=50:
            self.error += "Length should be not greater 20.\n"
            flag=False
        if not any(char.isdigit() for char in mp):
            self.error += "Password should have at least one numeral.\n"
            flag=False     
        if not any(char.isupper() for char in mp):
            self.error += "Password should have at least one uppercase letter.\n"
            flag=False
        if not any(char.islower() for char in mp):
            self.error += "Password should have atleast one lowercase.\n"
            flag=False
        if not any(char in specsym for char in mp):
            self.error += "Password should have atleast one special symbol: $@#%\n"
            flag=False
            
        return flag
class MPLoginPage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Changing Details -',style='Title.TLabel')
        title.grid(row=0,column=0)
        subtitle = Label(self, text='- Log in -',style='Subtitle.TLabel')
        subtitle.grid(row=1,column=0)

        self.user=Entry(self, font=('Patua One',10))
        self.mp=Entry(self, font=('Patua One',10),show='*')

        self.user.grid(row=3,column=0)
        self.mp.grid(row=5,column=0)

        utext=Label(self,text="Enter your user name: ",style='Text.TLabel').grid(row=2,column=0)
        self.user.insert(0,"")
        mptext=Label(self,text="Enter your master password: ",style='Text.TLabel').grid(row=4,column=0)
        self.mp.insert(0,"")

        hintButton=Button(self,text="MP Hint",style='Button.TButton',command=lambda: self.showHint()).grid(row=6,column=0)

        space = Label(self,text="").grid(row=7,column=0)
        enterButton=Button(self,text="Enter",style='Button.TButton',command=lambda: self.loginCheck()).grid(row=8,column=0)
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back()).grid(row=9,column=0)
    def show(self):
        try:
            with open('MP.bin','rb') as f:
                test = pickle.load(f)
        except FileNotFoundError:
            messagebox.showinfo(title="No Account",message=f"No account created on this device.",icon='warning')
            return
        except EOFError:
            messagebox.showinfo(title="No Account",message=f"No account created on this device.",icon='warning')
            return
        
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        self.enterBind =root.bind('<Return>',self.loginCheck)
        menu.place_forget()
    def back(self):
        root.unbind('<Return>',self.enterBind)
        self.hide()
        self.clearFields()
        menu.show()
    def loginCheck(self,*args):
        user = self.user.get()
        mp = self.mp.get()

        try:
            with open('MP.bin','rb') as f:
                if user != pickle.load(f):
                    messagebox.showinfo(title="Incorrect Username",message=f"Username not found on device.",icon='warning')
                elif mp != decrypt(pickle.load(f),mp):
                    messagebox.showinfo(title="Incorrect Password",message=f"Incorrect Password.",icon='warning')
                else:
                    mpchangepage.oldmp = mp
                    root.unbind('<Return>',self.enterBind)
                    mpchangepage.show()
                    self.clearFields()
                    self.hide()
        except EOFError:
            pass
    def clearFields(self):
        self.user.delete(0,'end')
        self.mp.delete(0,'end')
    def showHint(self):
        with open('MP.bin','rb') as f:
            offset = (pickle.load(f),pickle.load(f))
            messagebox.showinfo(title='Master Password Hint',message=f'Hint: {pickle.load(f)}')
class MPChangePage(Page):
    def __init__(self, *args, **kwargs):
        Page.__init__(self, *args, **kwargs)
        self.place(anchor='center',relx=0.5,rely=0.5)

        title = Label(self, text='- Changing Details -',style='Title.TLabel')
        title.grid(row=0,column=0)
        subtitle = Label(self, text='- New Details -',style='Subtitle.TLabel')
        subtitle.grid(row=1,column=0)

        self.user=Entry(self,style='Entry.TEntry',font=('Patua One',10))
        self.mp=Entry(self,style='Entry.TEntry',font=('Patua One',10),show='*')
        self.cmp=Entry(self,style='Entry.TEntry',font=('Patua One',10),show='*')
        self.hint=Entry(self,style='Entry.TEntry',font=('Patua One',10))

        self.user.grid(row=3,column=0)
        self.mp.grid(row=5,column=0)
        self.cmp.grid(row=7,column=0)
        self.hint.grid(row=9,column=0)

        utext=Label(self,text="Enter your username: ",style='Text.TLabel').grid(row=2,column=0)
        self.user.insert(0,"")
        mptext=Label(self,text="Enter your new master password: ",style='Text.TLabel').grid(row=4,column=0)
        self.mp.insert(0,"")
        cmptext=Label(self,text="Confirm new master password: ",style='Text.TLabel').grid(row=6,column=0)
        self.cmp.insert(0,"")
        hinttext=Label(self,text="Master Password Hint: ",style='Text.TLabel').grid(row=8,column=0)
        self.hint.insert(0,"")

        self.oldmp = ''

        space = Label(self,text="").grid(row=10,column=0)
        submitButton=Button(self,text="Submit",style='Button.TButton',command=lambda: self.submitter()).grid(row=11,column=0)
        backButton = Button(self, text='Back',style='Button.TButton',command=lambda: self.back())
        backButton.grid(row=12,column=0)
    def show(self):
        self.place(anchor='center',relx=0.5,rely=0.5)
        self.lift()
        self.enterBind = root.bind('<Return>',func= self.submitter)
        menu.place_forget()
    def back(self):
        self.hide()
        menu.show()
        self.clearFields()
        root.unbind('<Return>', self.enterBind)
    def submitter(self, *args):
        user=self.user.get()
        mp=self.mp.get()
        self.newmp = mp
        cmp=self.cmp.get()
        hint=self.hint.get()
        if not self.mpcheck(mp,cmp):
            messagebox.showinfo(title="Password Checker",message=f"Password Requirements not met:\n{self.error}",icon='warning')
        if self.mpcheck(mp,cmp):
            messagebox.showinfo(title="Account Modification Successful",message=f"Account Modification Successful.")
            with open('MP.bin','wb') as f:
                pickle.dump(user,f)
                pickle.dump(encrypt(mp,mp),f)
                pickle.dump(hint,f)
            self.reencryptPW()
            self.hide()
            menu.show()
            root.unbind('<Return>', self.enterBind)
    def reencryptPW(self):
        cur.execute('select * from passwords;')
        passwords = cur.fetchall()
        oldpw = {}
        for entry in passwords:
            oldpw[entry[0]] = [decrypt(entry[3],self.oldmp),decrypt(entry[4],self.oldmp)]
        newpw = {}
        for sno in oldpw:
            newpw[sno] = [encrypt(oldpw[sno][0],self.newmp).decode(),encrypt(oldpw[sno][1],self.newmp).decode()]
        for sno in newpw:
            cur.execute('update passwords set username = %s, passwd = %s where sno = %s',(newpw[sno][0],newpw[sno][1],sno))
        mydb.commit()
    def mpcheck(self,mp,cmp): 
        specsym=["$","@","#","%","_","&","*"]
        flag=True
        self.error = ""

        if len(mp)<8:
            self.error += "Length should be atleast 8.\n"
            flag=False
        if len(mp)>=50:
            self.error += "Length should be not greater 20.\n"
            flag=False
        if not any(char.isdigit() for char in mp):
            self.error += "Password should have at least one numeral.\n"
            flag=False
        if not any(char.isupper() for char in mp):
            self.error += "Password should have at least one uppercase letter.\n"
            flag=False
        if not any(char.islower() for char in mp):
            self.error += "Password should have atleast one lowercase.\n"
            flag=False
        if not any(char in specsym for char in mp):
            self.error += "Password should have atleast one special symbol: $@#%\n"
            flag=False
        if mp != cmp:
            self.error += "Passwords do not match.\n"
            flag=False

        return flag
    def clearFields(self):
        self.user.delete(0,'end')
        self.mp.delete(0,'end')
        self.cmp.delete(0,'end')
        self.hint.delete(0,'end')

regpage = RegPage(rootFrame)
regpage.hide()
logpage = LoginPage(rootFrame)
logpage.hide()
managerpage = ManagerPage(rootFrame)
managerpage.hide()
addpasspage = AddPassPage(rootFrame)
addpasspage.hide()
mploginpage = MPLoginPage(rootFrame)
mploginpage.hide()
mpchangepage = MPChangePage(rootFrame)
mpchangepage.hide()
menu = Menu(rootFrame)

root.mainloop()